package p2w.Interface;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.UIManager;

class ICON
{
	BufferedImage frameImage;

	static void setFrameIcon(JFrame currentFrame){
		BufferedImage frameImage=null;
		try {
			;
			//frameImage = ImageIO.read(currentFrame.getClass().getResource("/resources/p2wIcon.png"));

			frameImage = ImageIO.read(new File("p2wIcon.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 currentFrame.setIconImage(frameImage);
	}

	
}

public class P2W {

	public static void main(String[] args) {

		try {

			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");

		     //UIManager.put("textForeground", new ColorUIResource(255, 0, 0));
			//UIManager.put("Button.background", new ColorUIResource(255, 0, 0));

			UIManager.put("TextArea.background", new Color(242, 242, 242));
			UIManager.put("TextField.background", new Color(242, 242, 242));

		} catch (Exception e) {
			System.out.print(e.getMessage());

		}

		//SelectOptionsInsForm optionInsForm = new SelectOptionsInsForm();
		//SelectOptionsAdjForm optionAdjForm = new SelectOptionsAdjForm();
		//OutFileForm printFile = new OutFileForm();
		MainForm mainForm=new MainForm();
	}

}
