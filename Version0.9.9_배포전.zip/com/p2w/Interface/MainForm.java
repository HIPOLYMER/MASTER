package p2w.Interface;

import p2w.DataBase.*;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;



class MainForm extends JFrame{

	private JPanel mainContent_P, home_P, dbManage_P, probManage_P;
	private JPanel subject_P, basic_P, basicLabel_P, basicText_P;
	private JPanel persub_P, large_P, medium_P, small_P;
	private JPanel blank_P, probIns_P, probAdj_P, outFile_P;
	private JTabbedPane mainTabbed_P;
	private JScrollPane	dbManage_Scr;
	private JLabel year_L, subject_L;
	private JLabel large_L, medium_L, small_L;
	private JTextField year_TB, subject_TB;
	private JTextField large_TB, medium_TB, small_TB;
	private JButton add_Btn, dbClear_Btn;
	private JButton probIns_Btn, probAdj_Btn, outFile_Btn;
	private Box button_Box;
	private Dimension resolution;
	private Component subject_glue, button_glue, button_glue_1, button_glue_2;
	private JFrame thisFrame;
	MainForm()
	{
		//=============��� ���� �ʱ�ȭ==============//
		thisFrame=this;
		//�г� �ʱ�ȭ
		mainContent_P= new JPanel();
		mainTabbed_P=new JTabbedPane(JTabbedPane.TOP);
		mainTabbed_P.addChangeListener(new tabFocusListener());
		home_P=new JPanel();
		dbManage_P=new JPanel();
		probManage_P=new JPanel();

		blank_P = new JPanel();
		probIns_P=new JPanel();
		probAdj_P=new JPanel();
		outFile_P=new JPanel();
		dbManage_Scr=new JScrollPane(dbManage_P);

		subject_P = new JPanel();
		basic_P=new JPanel();
		basicLabel_P=new JPanel();
		basicText_P= new JPanel();
		persub_P= new JPanel();
		large_P=new JPanel();
		medium_P=new JPanel();
		small_P=new JPanel();

		//���̺� �ʱ�ȭ
		year_L=new JLabel("����⵵");
		subject_L=new JLabel("����");
		large_L=new JLabel("�� �з�");
		medium_L=new JLabel("�� �з�");
		small_L=new JLabel("�� �з�");

		//�ؽ�Ʈ �ʵ� �ʱ�ȭ
		year_TB=new JTextField();
		subject_TB=new JTextField();
		large_TB=new JTextField();
		medium_TB=new JTextField();
		small_TB=new JTextField();

		//��ư, Box �ʱ�ȭ
		add_Btn= new JButton("�߰�");
		dbClear_Btn= new JButton("�ʱ�ȭ");
		probIns_Btn=new JButton("���� �Է�");
		probAdj_Btn=new JButton("���� ����");
		outFile_Btn=new JButton("���� ���");
		button_Box= Box.createHorizontalBox();

		resolution=Toolkit.getDefaultToolkit().getScreenSize();

		subject_glue=Box.createGlue();
		button_glue=Box.createGlue();
		button_glue_1=Box.createGlue();
		button_glue_2=Box.createGlue();


		Color groundColor= new Color(245,245,245);
		Color btnColor=new Color(200, 200, 200);
		Font labelFont= new Font("��������", Font.BOLD,13);
		Font font = new Font("��������", Font.PLAIN,12);

		//=============��� ���� �ʱ�ȭ ��==============//
		setTitle("P2W");
		setBounds(0, 0, 400, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setContentPane(mainContent_P);

		ICON.setFrameIcon(this);
		this.resize(new Dimension(1000,1000));

		mainContent_P.setLayout(new BoxLayout(mainContent_P, BoxLayout.Y_AXIS));
		mainTabbed_P.setPreferredSize(new Dimension(400, 400));
		mainContent_P.add(mainTabbed_P);

		//tab����
		home_P.setPreferredSize(new Dimension(600, 400));
		home_P.setLayout(new BoxLayout(home_P, BoxLayout.Y_AXIS));


		JPanel mainImage_P= new JPanel();
		mainImage_P.setBorder(new EmptyBorder(30,0,0,0));
		mainImage_P.setMaximumSize(new Dimension(300,230));
		mainImage_P.setPreferredSize(new Dimension(300, 230));


		ImageIcon image = new ImageIcon("mainPage.png");
		JLabel image_L = new JLabel(image);
		mainImage_P.add(image_L);
		home_P.add(mainImage_P);

		dbManage_P.setPreferredSize(new Dimension(600, 400));
		dbManage_P.setLayout(new BoxLayout(dbManage_P, BoxLayout.Y_AXIS));

		dbManage_Scr.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		dbManage_Scr.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		dbManage_Scr.setPreferredSize(new Dimension(600, 400));
		probManage_P.setPreferredSize(new Dimension(600, 400));
		probManage_P.setLayout(new BoxLayout(probManage_P, BoxLayout.Y_AXIS));


		//==================dbManage_P����=======================//

		//basic_P
		basic_P.setBorder(new TitledBorder(null, "�⵵, ȸ��", TitledBorder.LEADING, TitledBorder.ABOVE_TOP, labelFont, null));
		basic_P.setLayout(new BoxLayout(basic_P, BoxLayout.PAGE_AXIS));
		basic_P.setMaximumSize(new Dimension(300, 130));
		basic_P.setMinimumSize(new Dimension(300, 130));
		basic_P.setPreferredSize(new Dimension(300, 130));
		basic_P.setLayout(new BoxLayout(basic_P, BoxLayout.Y_AXIS));

		basicLabel_P.setMaximumSize(new Dimension((int)resolution.getWidth(), 30));

		year_L.setPreferredSize(new Dimension(100, 30));
		year_L.setBorder(new EmptyBorder(10, 10, 0, 0));
		year_L.setFont(font);
		year_TB.setPreferredSize(new Dimension(100, 30));
		year_TB.setName("year");

		//persub_P
		persub_P.setBorder(new TitledBorder(null, "����, ��/��/�� �з�", TitledBorder.LEADING, TitledBorder.ABOVE_TOP, labelFont, null));
		persub_P.setLayout(new BoxLayout(persub_P, BoxLayout.PAGE_AXIS));
		persub_P.setMaximumSize(new Dimension(600,250));
		persub_P.setMinimumSize(new Dimension(600,250));
		persub_P.setPreferredSize(new Dimension(600,250));

		subject_P.setLayout(new BoxLayout(subject_P, BoxLayout.LINE_AXIS));
		subject_P.setMaximumSize(new Dimension(200, 40));

		subject_glue.setMaximumSize(new Dimension(5, 30));
		subject_glue.setPreferredSize(new Dimension(5, 30));

		subject_L.setMaximumSize(new Dimension(50, 30));
		subject_L.setPreferredSize(new Dimension(50, 30));
		subject_L.setBorder(new EmptyBorder(10, 10, 0, 0));
		subject_L.setFont(font);

		subject_TB.setMaximumSize(new Dimension(200, 40));
		subject_TB.setPreferredSize(new Dimension(200, 40));
		subject_TB.setName("subject");

		large_P.setMaximumSize(new Dimension((int)resolution.getWidth(), 50));
		large_TB.setPreferredSize(new Dimension(500, 35));
		large_TB.setName("large");

		medium_P.setMaximumSize(new Dimension((int)resolution.getWidth(), 50));
		medium_TB.setPreferredSize(new Dimension(500, 35));
		medium_TB.setName("medium");

		small_P.setMaximumSize(new Dimension((int)resolution.getWidth(), 50));
		small_TB.setPreferredSize(new Dimension(500, 35));
		small_TB.setName("small");


		large_L.setFont(font);
		medium_L.setFont(font);
		small_L.setFont(font);
		//�߰� ��ư �� �۷�
		button_Box.setMaximumSize(new Dimension(600,100));
		button_Box.setMinimumSize(new Dimension(600,100));
		button_Box.setPreferredSize(new Dimension(600, 100));
		button_glue.setMaximumSize(new Dimension(5, 32767));

		add_Btn.setName("add_Btn");
		add_Btn.setFont(labelFont);
		add_Btn.addActionListener(new MainFormBtnListener());
		add_Btn.setMaximumSize(new Dimension(70, 45));
		add_Btn.setPreferredSize(new Dimension(70, 45));

		//�߰� ��ư�� �ʱ�ȭ��ư ���� �۷�
		button_glue_1.setMaximumSize(new Dimension(520, 32767));

		dbClear_Btn.setName("dbClear_Btn");
		dbClear_Btn.setFont(font);
		dbClear_Btn.addActionListener(new MainFormBtnListener());
		dbClear_Btn.setMaximumSize(new Dimension(70, 30));
		dbClear_Btn.setPreferredSize(new Dimension(70, 30));

		button_glue_2.setMaximumSize(new Dimension(5, 32767));


		//color��

		mainTabbed_P.setBackground(groundColor);
		home_P.setBackground(new Color(255,255,255));
		mainImage_P.setBackground(new Color(255,255,255));
		dbManage_P.setBackground(groundColor);
		probManage_P.setBackground(groundColor);
		basic_P.setBackground(groundColor);
		basicLabel_P.setBackground(groundColor);
		basicText_P.setBackground(groundColor);
		persub_P.setBackground(groundColor);
		subject_P.setBackground(groundColor);
		large_P.setBackground(groundColor);
		medium_P.setBackground(groundColor);
		small_P.setBackground(groundColor);
		add_Btn.setBackground(groundColor);
		dbClear_Btn.setBackground(Color.RED);

		//������Ʈ�� add����

		mainTabbed_P.addTab("Home", null, home_P, null);
		mainTabbed_P.addTab("DB����", null, dbManage_Scr, null);
		mainTabbed_P.addTab("���� ����", null, probManage_P, null);

		//basic_P

		basic_P.add(basicLabel_P);
		basic_P.add(basicText_P);

		basicLabel_P.add(year_L);
		basicLabel_P.add(subject_L);
		basicText_P.add(year_TB);
		basicText_P.add(subject_TB);

		//persub_P

		subject_P.add(subject_L);
		subject_P.add(subject_glue);
		subject_P.add(subject_TB);
		persub_P.add(subject_P);
		persub_P.add(large_P);
		persub_P.add(medium_P);
		persub_P.add(small_P);

		large_P.add(large_L);
		large_P.add(large_TB);
		medium_P.add(medium_L);
		medium_P.add(medium_TB);
		small_P.add(small_L);
		small_P.add(small_TB);

		//button_Box
		button_Box.add(button_glue);
		button_Box.add(dbClear_Btn);
		button_Box.add(button_glue_1);
		button_Box.add(add_Btn);
		button_Box.add(button_glue_2);

		//dbManage_P
		dbManage_P.add(basic_P);
		dbManage_P.add(persub_P);
		dbManage_P.add(button_Box);


		//=======================dbManage_P ���� ��=================//

		//==================probManage_P ����=====================//

		Font probFont = new Font("��������", Font.BOLD,14);

		probIns_Btn.setName("probIns_Btn");
		probIns_Btn.addActionListener(new MainFormBtnListener());
		probIns_Btn.setMaximumSize(new Dimension(320, 40));
		probIns_Btn.setPreferredSize(new Dimension(320, 40));
		probIns_Btn.setBackground(btnColor);
		probIns_Btn.setForeground(new Color(217, 0, 35));
		probIns_Btn.setFont(probFont);

		probAdj_Btn.setName("probAdj_Btn");
		probAdj_Btn.addActionListener(new MainFormBtnListener());
		probAdj_Btn.setMaximumSize(new Dimension(320, 40));
		probAdj_Btn.setPreferredSize(new Dimension(320, 40));
		probAdj_Btn.setBackground(btnColor);
		probAdj_Btn.setForeground(new Color(224, 100, 0));
		probAdj_Btn.setFont(probFont);

		outFile_Btn.setName("outFile_Btn");
		outFile_Btn.addActionListener(new MainFormBtnListener());
		outFile_Btn.setMaximumSize(new Dimension(320, 40));
		outFile_Btn.setPreferredSize(new Dimension(320, 40));
		outFile_Btn.setBackground(btnColor);
		outFile_Btn.setForeground(new Color(0, 75, 246));
		outFile_Btn.setFont(probFont);

		blank_P.setMaximumSize(new Dimension((int)resolution.getWidth(), 80));
		blank_P.setPreferredSize(new Dimension(600, 80));
		blank_P.setBackground(groundColor);

		probIns_P.setMaximumSize(new Dimension((int)resolution.getWidth(), 60));
		probIns_P.setPreferredSize(new Dimension(600, 60));
		probIns_P.setBackground(groundColor);

		probAdj_P.setMaximumSize(new Dimension((int)resolution.getWidth(), 60));
		probAdj_P.setPreferredSize(new Dimension(600, 60));
		probAdj_P.setBackground(groundColor);

		outFile_P.setMaximumSize(new Dimension((int)resolution.getWidth(), 60));
		outFile_P.setPreferredSize(new Dimension(600, 60));
		outFile_P.setBackground(groundColor);

		probIns_P.add(probIns_Btn);
		probAdj_P.add(probAdj_Btn);
		outFile_P.add(outFile_Btn);

		probManage_P.setBackground(groundColor);
		probManage_P.add(blank_P);
		probManage_P.add(probIns_P);
		probManage_P.add(probAdj_P);
		probManage_P.add(outFile_P);


		//pack();
		setVisible(true);
	}

	private class MainFormBtnListener implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			JButton evt_Btn = (JButton)e.getSource();
			if(evt_Btn.getName()=="probIns_Btn")
			{
				SelectOptionsInsForm selectOptionsIns = new SelectOptionsInsForm();
			}
			else if(evt_Btn.getName()=="probAdj_Btn")
			{
				SelectOptionsAdjForm selectOptionsAdj = new SelectOptionsAdjForm();
			}
			else if(evt_Btn.getName()=="outFile_Btn")
			{
				OutFileForm printFile = new OutFileForm();
			}
			else if(evt_Btn.getName()=="dbClear_Btn")
			{
				MessageCall message = new MessageCall();
				int yesNo1=0;
				int yesNo2=0;
				int check=0;
				yesNo1 = message.yesnoMessage(null, "���� �ʱ�ȭ �Ͻðڽ��ϱ�?");
				if(yesNo1 == JOptionPane.YES_OPTION){
					yesNo2 = message.yesnoMessage(null, "��� ������ �������ϴ�.");
					if(yesNo2 == JOptionPane.YES_OPTION){
						Query query = new Query();
						check=query.dbInit();
						if(check==0)
							message.alertMessage(null, "�ʱ�ȭ �Ϸ�");
						else
							message.alertMessage(null, "�ʱ�ȭ ���� ������ �߻��߽��ϴ�.\n");
						query.close();
					}
				}
			}
			else if(evt_Btn.getName()=="add_Btn")
			{
				Query query = new Query();
				MessageCall message = new MessageCall();

				String year_str=year_TB.getText().trim();
				String subject_str=subject_TB.getText().trim();

				if(year_str.isEmpty() && subject_str.isEmpty()){
					System.out.println("empty");
					message.alertMessage(null, "�Էµ� �׸��� �����ϴ�.");
				}
				else{
					if(!year_str.isEmpty()){
						int check;

						check = query.doInserts("basicoption1","null,\""+year_TB.getText().toString()+"\",\"1\"");
						if(check == 0){
							query.doInserts("basicoption1","null,\""+year_TB.getText().toString()+"\",\"2\"");
							query.doInserts("basicoption1","null,\""+year_TB.getText().toString()+"\",\"3\"");
							query.doInserts("basicoption1","null,\""+year_TB.getText().toString()+"\",\"4\"");
							message.alertMessage(null, "���ο� �⵵�� �߰��Ǿ����ϴ�.");
						}else{
							message.alertMessage(null, year_TB.getText().toString()+"�⵵ �߰��� �����Ͽ����ϴ�.");
						}

					}

					if(!subject_str.isEmpty()){
						//MessageCall message = new MessageCall();
						query.doInserts("basicoption2","null,\"A\",\""+subject_TB.getText().toString()+"\"");
						query.doInserts("basicoption2","null,\"B\",\""+subject_TB.getText().toString()+"\"");
						if(!large_TB.getText().trim().isEmpty()){
							if(!medium_TB.getText().trim().isEmpty()){
								if(!small_TB.getText().isEmpty()){
									query.doInserts("classification","null,\""+subject_TB.getText().toString()+"\""
											+",\""+large_TB.getText().toString()+"\""
											+",\""+medium_TB.getText().toString()+"\""
											+",\""+small_TB.getText().toString()+"\"");
									message.alertMessage(null, "����,��з�,�ߺз�,�Һз� �߰� �Ϸ�");
								}else{
									query.doInserts("classification","null,\""+subject_TB.getText().toString()+"\""
											+",\""+large_TB.getText().toString()+"\""
											+",\""+medium_TB.getText().toString()+"\""
											+",\"null\"");
									message.alertMessage(null, "����,��з�,�ߺз� �߰� �Ϸ�");
								}
							}else{
								query.doInserts("classification","null,\""+subject_TB.getText().toString()+"\""
										+",\""+large_TB.getText().toString()+"\""
										+",\"null\""
										+",\"null\"");
								message.alertMessage(null, "����,��з� �߰� �Ϸ�");
							}
						}else{
							query.doInserts("classification","null,\""+subject_TB.getText().toString()+"\""
									+",\"null\""
									+",\"null\""
									+",\"null\"");
							message.alertMessage(null, "���� �߰� �Ϸ�");
						}


					}
				}
				query.close();
			}

		}

	}//MainFormBtnListener
	public class tabFocusListener implements ChangeListener
	{

		@Override
		public void stateChanged(ChangeEvent focusedTab) {
			// TODO Auto-generated method stub
			System.out.println("getFocused!!");
			 if (focusedTab.getSource() instanceof JTabbedPane) {
                JTabbedPane pane = (JTabbedPane) focusedTab.getSource();
                System.out.println("Selected paneNo : " + pane.getSelectedIndex());
                int selectedIndex=pane.getSelectedIndex();
                if( selectedIndex==0 || selectedIndex==2)
                	thisFrame.resize(new Dimension(400,400));
                else if( selectedIndex==1)
                	thisFrame.resize(new Dimension(700,550));


            }
		}



	}

}
