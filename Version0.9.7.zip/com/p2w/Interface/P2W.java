package p2w.Interface;

import java.awt.Color;
import java.awt.Font;

import javax.swing.UIManager;

public class P2W {

	public static void main(String[] args) {

		try {
			// UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			// 1. �ڹ� ���� �����
			//UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
			//UIManager.setLookAndFeel("com.apple.laf.AquaLookAndFeel");
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
			// UIManager.put("nimbusBase", new Color(238, 238, 238));
		     //UIManager.put("textForeground", new ColorUIResource(255, 0, 0));
			//UIManager.put("Button.background", new ColorUIResource(255, 0, 0));
			UIManager.put("TextArea.background", new Color(242, 242, 242));
			UIManager.put("TextField.background", new Color(242, 242, 242));
			
		} catch (Exception e) {
			System.out.print(e.getMessage());

		}

		//SelectOptionsInsForm optionInsForm = new SelectOptionsInsForm();
		//SelectOptionsAdjForm optionAdjForm = new SelectOptionsAdjForm();
		//OutFileForm printFile = new OutFileForm();
		MainForm mainForm=new MainForm();
	}

}
