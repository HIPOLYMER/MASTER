package p2w.Interface;

import javax.swing.UIManager;

public class P2W {

	public static void main(String[] args) {

		try {
			// UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			// 1. �ڹ� ���� �����
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
			//UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");

		} catch (Exception e) {
			System.out.print(e.getMessage());
		}

		//SelectOptionsInsForm optionInsForm = new SelectOptionsInsForm();
		//SelectOptionsAdjForm optionAdjForm = new SelectOptionsAdjForm();
		//OutFileForm printFile = new OutFileForm();
		MainForm mainForm=new MainForm();
	}

}
